#include "Memoria.h"
using namespace Trabajo_Parcial;
int main() {
	Application::Run(gcnew Memoria());
	return 0;
}