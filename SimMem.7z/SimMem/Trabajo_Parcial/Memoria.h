#pragma once
#include <iostream>
#include <iomanip>
#include <conio.h>
#include <stdlib.h>
using namespace std;

namespace Trabajo_Parcial {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de Memoria
	/// </summary>
	public ref class Memoria : public System::Windows::Forms::Form
	{
	public:

		int size = 1 << 20;
		Byte* mem = new Byte[size];
		int address = 0;
		typedef unsigned char Byte;
		void printMem(Byte* mem, int initaddr, int size) {
			int addr = initaddr;
			cout << " Address  +0 +1 +2 +3 +4 +5 +6 +7  +8 +9 +a +b +c +d +e +f\n"
				<< "--------++--+--+--+--+--+--+--+--++--+--+--+--+--+--+--+--+"
				<< setfill('0') << hex;
			for (int i = 0; i < size; i++) {
				if (i % 16 == 0) cout << endl << setw(8) << (addr + i) << " "; // direcciones
				else if (i % 8 == 0) cout << " "; // espacio central extra
				cout << " " << setw(2) << (int)mem[addr + i];
			}
			cout << dec << endl; // regresamos a impresion normal (sistema decimal)
		}

		void writeMem(Byte* mem, int addr, Byte* data, int numBytes) {
			for (int i = 0; i < numBytes; i++) {
				mem[addr + i] = data[i];
			}
		}

		void readMem(Byte* mem, int addr, Byte* data, int numBytes) {
			for (int i = 0; i < numBytes; i++) {
				data[i] = mem[addr + i];
			}
		}

	private: System::Windows::Forms::Label^  label7;
	public:
	private: System::Windows::Forms::Button^  button7;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Button^  button8;
	private: System::Windows::Forms::TextBox^  textBox7;
			

		Memoria(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~Memoria()
		{
			if (components)
			{
				delete components;
			}
		}

	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::TextBox^  textBox3;
	private: System::Windows::Forms::TextBox^  textBox4;
	private: System::Windows::Forms::TextBox^  textBox5;
	private: System::Windows::Forms::Button^  button6;
	private: System::Windows::Forms::TextBox^  textBox6;
	private: System::Windows::Forms::Label^  label6;

	private: System::ComponentModel::IContainer^  components;


	protected:

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->textBox6 = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->textBox7 = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(168, 10);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 1;
			this->button1->Text = L"button1";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Memoria::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(168, 43);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 2;
			this->button2->Text = L"button2";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Memoria::button2_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(61, 12);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(100, 20);
			this->textBox1->TabIndex = 3;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &Memoria::textBox1_TextChanged);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(37, 12);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(18, 13);
			this->label1->TabIndex = 5;
			this->label1->Text = L"int";
			this->label1->Click += gcnew System::EventHandler(this, &Memoria::label1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(28, 75);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(27, 13);
			this->label2->TabIndex = 6;
			this->label2->Text = L"float";
			this->label2->Click += gcnew System::EventHandler(this, &Memoria::label2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(27, 43);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(28, 13);
			this->label3->TabIndex = 7;
			this->label3->Text = L"char";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(12, 104);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(47, 13);
			this->label4->TabIndex = 8;
			this->label4->Text = L"longlong";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(16, 136);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(39, 13);
			this->label5->TabIndex = 9;
			this->label5->Text = L"double";
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(168, 75);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 23);
			this->button3->TabIndex = 10;
			this->button3->Text = L"button3";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Memoria::button3_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(168, 104);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(75, 23);
			this->button4->TabIndex = 11;
			this->button4->Text = L"button4";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Memoria::button4_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(168, 133);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(75, 23);
			this->button5->TabIndex = 12;
			this->button5->Text = L"button5";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Memoria::button5_Click);
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(62, 43);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(100, 20);
			this->textBox2->TabIndex = 13;
			this->textBox2->TextChanged += gcnew System::EventHandler(this, &Memoria::textBox2_TextChanged_1);
			// 
			// textBox3
			// 
			this->textBox3->Location = System::Drawing::Point(62, 75);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(100, 20);
			this->textBox3->TabIndex = 14;
			this->textBox3->TextChanged += gcnew System::EventHandler(this, &Memoria::textBox3_TextChanged);
			// 
			// textBox4
			// 
			this->textBox4->Location = System::Drawing::Point(62, 104);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(100, 20);
			this->textBox4->TabIndex = 15;
			this->textBox4->TextChanged += gcnew System::EventHandler(this, &Memoria::textBox4_TextChanged);
			// 
			// textBox5
			// 
			this->textBox5->Location = System::Drawing::Point(62, 133);
			this->textBox5->Name = L"textBox5";
			this->textBox5->Size = System::Drawing::Size(100, 20);
			this->textBox5->TabIndex = 16;
			this->textBox5->TextChanged += gcnew System::EventHandler(this, &Memoria::textBox5_TextChanged);
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(168, 162);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(75, 23);
			this->button6->TabIndex = 17;
			this->button6->Text = L"button6";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &Memoria::button6_Click);
			// 
			// textBox6
			// 
			this->textBox6->Location = System::Drawing::Point(61, 160);
			this->textBox6->Name = L"textBox6";
			this->textBox6->Size = System::Drawing::Size(100, 20);
			this->textBox6->TabIndex = 18;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(16, 162);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(43, 13);
			this->label6->TabIndex = 19;
			this->label6->Text = L"puntero";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(347, 8);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(84, 13);
			this->label7->TabIndex = 20;
			this->label7->Text = L"Mostrar memoria";
			// 
			// button7
			// 
			this->button7->Location = System::Drawing::Point(292, 26);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(191, 49);
			this->button7->TabIndex = 21;
			this->button7->Text = L"button7";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &Memoria::button7_Click);
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(299, 91);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(169, 13);
			this->label8->TabIndex = 22;
			this->label8->Text = L"Arreglo de N Elementos (inserte N)";
			// 
			// button8
			// 
			this->button8->Location = System::Drawing::Point(311, 144);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(129, 36);
			this->button8->TabIndex = 23;
			this->button8->Text = L"button8";
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &Memoria::button8_Click);
			// 
			// textBox7
			// 
			this->textBox7->Location = System::Drawing::Point(325, 115);
			this->textBox7->Name = L"textBox7";
			this->textBox7->Size = System::Drawing::Size(100, 20);
			this->textBox7->TabIndex = 24;
			this->textBox7->TextChanged += gcnew System::EventHandler(this, &Memoria::textBox7_TextChanged);
			// 
			// Memoria
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(516, 222);
			this->Controls->Add(this->textBox7);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->textBox6);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->textBox5);
			this->Controls->Add(this->textBox4);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Name = L"Memoria";
			this->Text = L"Memoria";
			this->Load += gcnew System::EventHandler(this, &Memoria::Memoria_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Memoria_Load(System::Object^  sender, System::EventArgs^  e) {
		printMem(mem, 0, 320);
	}
	private: System::Void textBox2_TextChanged(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
}
        
		


private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void textBox2_TextChanged_1(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void textBox3_TextChanged(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void textBox4_TextChanged(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void textBox5_TextChanged(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
	unsigned char varint = Convert::ToInt32(textBox1->Text);
	writeMem(mem, address, (Byte*)&varint, sizeof(int));
	address += sizeof(int);
	printMem(mem, 0, 320);
}
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
	unsigned char varchar = Convert::ToChar(textBox2->Text);
	writeMem(mem, address, (Byte*)&varchar, sizeof(char));
	address += sizeof(char);
	printMem(mem, 0, 320);
}
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
	unsigned char varint = Convert::ToInt32(textBox1->Text);
	writeMem(mem, address, (Byte*)&varint, sizeof(int));
	address += sizeof(int);
	printMem(mem, 0, 320);
}
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
	unsigned char varint = Convert::ToInt32(textBox1->Text);
	writeMem(mem, address, (Byte*)&varint, sizeof(int));
	address += sizeof(int);
	printMem(mem, 0, 320);
}
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
	unsigned char varint = Convert::ToInt32(textBox1->Text);
	writeMem(mem, address, (Byte*)&varint, sizeof(int));
	address += sizeof(int);
	printMem(mem, 0, 320);
}
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) {
	unsigned char varint = Convert::ToInt32(textBox1->Text);
	writeMem(mem, address, (Byte*)&varint, sizeof(int));
	address += sizeof(int);
	printMem(mem, 0, 320);
}
private: System::Void button7_Click(System::Object^  sender, System::EventArgs^  e) {

}
private: System::Void button8_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void textBox7_TextChanged(System::Object^  sender, System::EventArgs^  e) {
}
};
}
