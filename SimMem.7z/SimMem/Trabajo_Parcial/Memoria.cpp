#include "Memoria.h"
//#include <iostream>
//#include <iomanip>
//
//using namespace std;
//
//typedef unsigned char Byte;
//
//void printMem(Byte* mem, int initaddr, int size) {
//	int addr = initaddr;
//	cout << " Address  +0 +1 +2 +3 +4 +5 +6 +7  +8 +9 +a +b +c +d +e +f\n"
//		<< "--------++--+--+--+--+--+--+--+--++--+--+--+--+--+--+--+--+"
//		<< setfill('0') << hex;
//	for (int i = 0; i < size; i++) {
//		if (i % 16 == 0) cout << endl << setw(8) << (addr + i) << " "; // direcciones
//		else if (i % 8 == 0) cout << " "; // espacio central extra
//		cout << " " << setw(2) << (int)mem[addr + i];
//	}
//	cout << dec << endl; // regresamos a impresi�n normal (sistema decimal)
//}
//
//void writeMem(Byte* mem, int addr, Byte* data, int numBytes) {
//	for (int i = 0; i < numBytes; i++) {
//		mem[addr + i] = data[i];
//	}
//}
//void readMem(Byte* mem, int addr, Byte* data, int numBytes) {
//	for (int i = 0; i < numBytes; i++) {
//		data[i] = mem[addr + i];
//	}
//}
//
//int main()
//{
//	int size = 1 << 20;
//	Byte* mem = new Byte[size];
//
//	cout << "Tamano de long long: " << sizeof(long long) << " bytes\n";
//	cout << "Tamano de memoria: " << size << " bytes\n";
//	cout << "Tamano de memoria: " << hex << size << " bytes\n";
//	mem[0x10] = 5;
//	int a = -1;
//	long long b = 100;
//	int c = 1024;
//	long long d = 0xabcdef123456;
//	float x[5] = { 1.1, 2.2, 3.3, 4.4, 5.5 };
//	writeMem(mem, 0, (Byte*)&a, sizeof(int));
//	writeMem(mem, 6, (Byte*)&b, sizeof(long long));
//	writeMem(mem, 20, (Byte*)&c, sizeof(int));
//	writeMem(mem, 5, (Byte*)&d, sizeof(long long));
//	readMem(mem, 6, (Byte*)&b, sizeof(long long));
//	writeMem(mem, 0x30, (Byte*)x, 5 * sizeof(float));
//	printMem(mem, 0, 200);
//	cout << "B: " << b << endl;
//
//	delete[] mem;
//	return 0;
//}
//
//
//
